package com.store.courseworkmain.model;


import java.util.HashSet;
import java.util.Set;

public class Order{
    public  static Set<Integer> item_id= new HashSet<>();

}
